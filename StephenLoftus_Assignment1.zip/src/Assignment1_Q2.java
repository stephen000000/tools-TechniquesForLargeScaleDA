import java.util.Comparator;

public class Assignment1_Q2 {
	Comparator comp;
	Object[] array;
	
	//Sort now takes in a comparator which allows it to sort objects of different types 
	 public void sort(Object[] array,Comparator c){ // array length must be a power of 2
		 
		 this.array = array;
		 comp = c;
		 sort(0, array.length);
	 }
	 

	 private void sort(int low, int n) {

		 if (n > 1) {
			 int mid = n >> 1;

			 sort(low, mid);
			 sort(low + mid, mid);

			 combine(low, n, 1);
		 }
	 }
	 
	 private void combine(int low, int n, int st) {

		int m = st << 1;

	 	if (m < n) {
	 		combine(low, n, m);
	 		combine(low + st, n, m);

	 		for (int i = low + st; i + st < low + n; i += m)
	 			compareAndSwap(i, i + st);

	 	} else
	 		compareAndSwap(low, low + st);
	 }
	 
	 // compares objects used on the comparator passed in sort
	 private void compareAndSwap(int i, int j) {
		 if (comp.compare(array[i],array[j]) > 0)
			 swap(i, j);
	 }

	private void swap(int i, int j) {
		 Object h = array[i];
		 array[i] = array[j];
		 array[j] = h;
	 } 
	 
	    
	 public static void main(String args[]) {

		//Create instance of class
		Assignment1_Q2 aa1 = new Assignment1_Q2();

		//Setting array length
		int arrayLength = 16;
		
		//Creating Array of doubles
		Double[] doubleArray = new Double[arrayLength];
		
		//Assigneing values for the doubles
		for (int i=0; i < doubleArray.length; i++) {
			doubleArray[i] =(double) (Math.random()*100+1);
		}
		
		//Creating comparator used to compare the doubles
		Comparator doubleComp = new Comparator<Double>() {
			@Override
			public int compare(Double d1, Double d2) {
				if(d1 > d2) {
					return 1;
				}
				return 0;
			}
		};	
		//printing out the array before the sort
		System.out.print("\nDouble Array before sort : \n");
		for (int i=0; i < doubleArray.length; i++) {
			System.out.print(doubleArray[i]+",");
		}
		
		System.out.print("\n");
		//calling the sort method
		aa1.sort(doubleArray,doubleComp);
		//printing out the sorted double array
		System.out.print("\nSorted Double Array :\n");
		for (int i=0; i < aa1.array.length; i++) {
			System.out.print(aa1.array[i]+",");
		}
		
		System.out.print("\n#########################################################\n");
		//Creating String array and adding strings to it
		String[] stringArray = new String[4];
		stringArray[0]= "This";
		stringArray[1]= "is";
		stringArray[2]= "a";
		stringArray[3]= "sentence";
		//printing out the array before calling sort
		System.out.print("\nString Array before sort : \n");
		for (int i=0; i < stringArray.length; i++) {
			System.out.print(stringArray[i]+",");
		}
		System.out.print("\n");
		//creating the string comparator
		Comparator stringComp = new Comparator<String>() {
			@Override
			public int compare(String s1, String s2) {
				return s1.compareToIgnoreCase(s2);
			}
		};
		//calling sort method
		aa1.sort(stringArray,stringComp);
		//printing out sorted string array
		System.out.print("\nSorted String Array :\n");
		for (int i=0; i < aa1.array.length; i++) {
			System.out.print(aa1.array[i]+",");
		}
	 }

}
