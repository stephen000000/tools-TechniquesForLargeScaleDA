public class Assignment1_Q4{
	
		int[] array;
		int counter = 0;
		boolean printed = false;
		
		

		public void sort(int[] array) { // array length must be a power of 2
		
		 this.array = array;
		 sort(0, array.length);
		}
		
		//synchronized to prevent multiple threads calling methods at the same time leading to errors
		private synchronized void sort(int low, int n) {
			if (n > 1) {
				int mid = n >> 1;
				
				//Creating and starting thread t1 and t2 which are used to call the sort method on the sub array
				Thread t1 = new Thread() {
					@Override
					public void run() {
						sort(low,mid);
					}
				};
				
				t1.start();

				Thread t2 = new Thread() {
					@Override
					public void run() {
						sort(low + mid, mid);

					}
				};

				t2.start();
			}
			//counter used to know when sorting is finished to print out array
			counter ++;
			combine(low, n, 1);
			//printing our sorted array
			if(counter == (array.length*2)-1 && printed == false) {
				System.out.print("\nSorted Int Array :\n");
				for (int i=0; i < array.length; i++) {
					System.out.print(array[i]+",");
				}
				printed = true;
			}
		}

		//synchroniszed to prevent incorrect combines occuring due to multiple threads running at once 
		private synchronized void combine(int low, int n, int st) {
			 int m = st << 1;
			 
			 if (m < n) {
				 combine(low, n, m);
				 combine(low + st, n, m);

				 for (int i = low + st; i + st < low + n; i += m)

					 compareAndSwap(i, i + st);

			 } else {
				compareAndSwap(low, low + st);
			 }
		 }
		 
		 private void compareAndSwap(int i, int j) {
			 try {
			 if (array[i] > array[j]) {
				 swap(i, j);
			 }
			 }catch(ArrayIndexOutOfBoundsException e) {
				 
			 }
		 }
		 
		 //method synchronized to prevent multiple swaps happening at once causing errors
		 private synchronized void swap(int i, int j) {
			int h = array[i];
			array[i] = array[j];
			array[j] = h; 	
		 } 
		 
		 
		 public static void main(String args[]) {
			// Creating instance of class
			Assignment1_Q4 aa1 = new Assignment1_Q4();
			// Setting length of array
			int arrayLength = 8;
			//Creating an array of ints and assigning values
			int[] intArray = new int[arrayLength];
			for (int i=0; i < intArray.length; i++) {
				intArray[i] =(int) (Math.random()*100+1);
			}
			
			//printing out the array before its sorted
			System.out.print("\nInt Array before sort : \n");
			for (int i=0; i < intArray.length; i++) {
				System.out.print(intArray[i]+",");
			}
			
			System.out.println("\n");
			//calling the sort method
			aa1.sort(intArray);
			
		 }

}
