import java.util.Comparator;

public class Assignment1_Q3 {
	//Everything same as Q2 expect main
	Comparator comp;
	Object[] array;
	
	 public void sort(Object[] array,Comparator c){ // array length must be a power of 2
		 
		 this.array = array;
		 comp = c;
		 sort(0, array.length);
	 }
	 

	 private void sort(int low, int n) {

		 if (n > 1) {
			 int mid = n >> 1;

			 sort(low, mid);
			 sort(low + mid, mid);

			 combine(low, n, 1);
		 }
	 }
	 
	 private void combine(int low, int n, int st) {

		int m = st << 1;

	 	if (m < n) {
	 		combine(low, n, m);
	 		combine(low + st, n, m);

	 		for (int i = low + st; i + st < low + n; i += m)
	 			compareAndSwap(i, i + st);

	 	} else
	 		compareAndSwap(low, low + st);
	 }
	 
	 private void compareAndSwap(int i, int j) {
		 if (comp.compare(array[i],array[j]) > 0)
			 swap(i, j);
	 }

	private void swap(int i, int j) {
		 Object h = array[i];
		 array[i] = array[j];
		 array[j] = h;
	 } 
	 
	   
	
	 public static void main(String args[]) {
		 //creating instance of class
		Assignment1_Q3 aa1 = new Assignment1_Q3();
		//Array length variable
		int arrayLength = 16;
		//Creatinmg double array
		Double[] doubleArray = new Double[arrayLength];
		for (int i=0; i < doubleArray.length; i++) {
			doubleArray[i] =(double) (Math.random()*100+1);
		}
		
		//Creating double comparator using Lambda expressions
		Comparator<Double> doubleComp = ((Double d1,Double d2)-> d1.compareTo(d2));
		//Printing out double array before sort
		System.out.print("\nDouble Array before sort : \n");
		for (int i=0; i < doubleArray.length; i++) {
			System.out.print(doubleArray[i]+",");
		}
		
		System.out.print("\n");
		//calling sort
		aa1.sort(doubleArray,doubleComp);
		//printing out double array after sort
		System.out.print("\nSorted Double Array :\n");
		for (int i=0; i < aa1.array.length; i++) {
			System.out.print(aa1.array[i]+",");
		}
		
		System.out.print("\n#########################################################\n");
		//Creating string array
		String[] stringArray = new String[4];
		stringArray[0]= "This";
		stringArray[1]= "is";
		stringArray[2]= "a";
		stringArray[3]= "sentence";
		//printing out string before sort
		System.out.print("\nString Array before sort : \n");
		for (int i=0; i < stringArray.length; i++) {
			System.out.print(stringArray[i]+",");
		}
		System.out.print("\n");
		//creating string comparator using lambda expression
		Comparator<String> stringComp = ((String s1,String s2)-> s1.compareTo(s2));
		//calling sort on string array
		aa1.sort(stringArray,stringComp);
		// printing out sorted arrayS
		System.out.print("\nSorted String Array :\n");
		for (int i=0; i < aa1.array.length; i++) {
			System.out.print(aa1.array[i]+",");
		}
	 }

}
