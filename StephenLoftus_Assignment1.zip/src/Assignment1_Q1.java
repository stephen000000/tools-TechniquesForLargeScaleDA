public class Assignment1_Q1 {
	int[] array;

	public void sort(int[] array) { // array length must be a power of 2
	 this.array = array;
	 sort(0, array.length);
	}
	
	private void sort(int low, int n) {
	 if (n > 1) {
		 int mid = n >> 1;
		 sort(low, mid);
		 sort(low + mid, mid);

		 combine(low, n, 1);
	 	}
	 }
	
	 private void combine(int low, int n, int st) {

		 int m = st << 1;
		 if (m < n) {
			 combine(low, n, m);
			 combine(low + st, n, m);

			 for (int i = low + st; i + st < low + n; i += m)
				 compareAndSwap(i, i + st);

		 	} else {
		 		compareAndSwap(low, low + st);
		 	}
	 }
	 
	 private void compareAndSwap(int i, int j) {
			 if (array[i] > array[j]) 
				 swap(i, j);
	 }
	 
	 private void swap(int i, int j) {
		 int h = array[i];
		 array[i] = array[j];
		 array[j] = h;
	 } 
	 
	 public static void main(String args[]) {

		// Creating instance of class
		Assignment1_Q1 aa1 = new Assignment1_Q1();

		// Setting length of array
		int arrayLength = 16;
		
		//Creating an array of ints and assigning values
		int[] intArray = new int[arrayLength];
		for (int i=0; i < intArray.length; i++) {
			intArray[i] =(int) (Math.random()*100+1);
		}
		
		//printing out the array before its sorted
		System.out.print("\nInt Array before sort : \n");
		for (int i=0; i < intArray.length; i++) {
			System.out.print(intArray[i]+",");
		}
		
		System.out.print("\n");
		
		//calling the sort method
		aa1.sort(intArray);
		 
		//printing out the sorted array
		System.out.print("\nSorted Int Array :\n");
		for (int i=0; i < aa1.array.length; i++) {
			System.out.print(aa1.array[i]+",");
		}
		
	 }
}
